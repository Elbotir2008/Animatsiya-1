let svg1=document.getElementById('svg1')
let svg2=document.getElementById('svg2')
function toggleBackground() {
    var body = document.body;
    body.classList.toggle("dark");
    svg1.style.display="inline-block"
    svg2.style.display="none"
}
const loading = document.getElementById("loading");
window.addEventListener("load", () => {
  loading.classList.add('loading-none');
}); 